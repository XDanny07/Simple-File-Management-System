import UploadFunc from "../components/UploadFunc";

export default function Upload() {
  return (
    <div className="mt-10">
      <UploadFunc />
    </div>
  );
}
